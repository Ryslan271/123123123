﻿using DemoExam.Pages;
using System.Windows;

namespace DemoExam
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register("Title", typeof(string), typeof(MainWindow));


        public MainWindow()
        {
            Title = string.Empty;
            InitializeComponent();
            App.MainWindowInstance = this;
            MyFrame.Navigate(new AuthorizationPage());
        }
    }
}
