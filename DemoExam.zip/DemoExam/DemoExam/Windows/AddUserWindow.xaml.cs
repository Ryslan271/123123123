﻿using DemoExam.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DemoExam.Windows
{
    public partial class AddUserWindow : Window
    {


        public User User
        {
            get { return (User)GetValue(UserProperty); }
            set { SetValue(UserProperty, value); }
        }

        public static readonly DependencyProperty UserProperty =
            DependencyProperty.Register("User", typeof(User), typeof(AddUserWindow));



        public List<Role> RolesList
        {
            get { return (List<Role>)GetValue(RolesListProperty); }
            set { SetValue(RolesListProperty, value); }
        }

        public static readonly DependencyProperty RolesListProperty =
            DependencyProperty.Register("RolesList", typeof(List<Role>), typeof(AddUserWindow));



        public AddUserWindow()
        {
            User = new User();
            RolesList = App.DataContext.Role.ToList();
            InitializeComponent();
            AddNewUserBTN.Click += (sender, e) =>
            {
                App.DataContext.User.Add(User);
                App.DataContext.SaveChanges();
            };
        }

    }
}
