﻿using DemoExam.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DemoExam.Windows
{
    /// <summary>
    /// Логика взаимодействия для ShiftUserWindow.xaml
    /// </summary>
    public partial class ShiftUserWindow : Window
    {


        public List<User> UsersInShift
        {
            get { return (List<User>)GetValue(UsersInShiftProperty); }
            set { SetValue(UsersInShiftProperty, value); }
        }

        public static readonly DependencyProperty UsersInShiftProperty =
            DependencyProperty.Register("UsersInShift", typeof(List<User>), typeof(ShiftUserWindow));


        public ObservableCollection<User> UsersExceptShift
        {
            get { return (ObservableCollection<User>)GetValue(UsersExceptShiftProperty); }
            set { SetValue(UsersExceptShiftProperty, value); }
        }

        public static readonly DependencyProperty UsersExceptShiftProperty =
            DependencyProperty.Register("UsersExceptShift", typeof(ObservableCollection<User>), typeof(ShiftUserWindow));

        public Shift Shift;

        public ShiftUserWindow(Shift shift)
        {
            Shift = shift;
            UsersInShift = App.DataContext.User.Where(u => u.UserShift.Any(us => us.IdShift == shift.Id)).ToList();
            UsersExceptShift = new ObservableCollection<User>(App.DataContext.User.ToList().Except(UsersInShift));
            InitializeComponent();
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(!(sender is ComboBox comboBox))
            {
                return;
            }
            
            if(comboBox.SelectedItem is null)
            {
                return;
            }

            var user = comboBox.SelectedItem as User;

            UsersInShift.Add(user);
            UsersExceptShift.Remove(user);
            userListView.Items.Refresh();
        }

        private void AddShiftUserBTN_Click(object sender, RoutedEventArgs e)
        {
            UsersInShift.ForEach(uis => App.DataContext.UserShift.Add(new UserShift
            {
                IdShift = Shift.Id,
                IdUser = uis.Id,
            }));

            App.DataContext.SaveChanges();
            Close();
        }
    }
}
