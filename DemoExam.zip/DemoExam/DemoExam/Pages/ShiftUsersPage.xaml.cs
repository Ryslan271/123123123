﻿using DemoExam.Model;
using DemoExam.Windows;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam.Pages
{
    public partial class ShiftUsersPage : Page
    {


        public ObservableCollection<Shift> Shifts
        {
            get { return (ObservableCollection<Shift>)GetValue(ShiftsProperty); }
            set { SetValue(ShiftsProperty, value); }
        }

        public static readonly DependencyProperty ShiftsProperty =
            DependencyProperty.Register("Shifts", typeof(ObservableCollection<Shift>), typeof(ShiftUsersPage));



        public ShiftUsersPage()
        {
            App.MainWindowInstance.Title = "Смены пользователей";
            App.DataContext.Shift.Load();
            Shifts = App.DataContext.Shift.Local;
            InitializeComponent();
            BackToAdminPanelBTN.Click += (sender, e) =>
            {
                App.MainWindowInstance.MyFrame.Navigate(new AdministratorPage());
            };
        }

        private void AddUserShift_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as Button;

            if(!(btn.DataContext is Shift shif))
            {
                MessageBox.Show("Ошибка! нет переданного значения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            new ShiftUserWindow(shif).ShowDialog();
        }
    }
}
