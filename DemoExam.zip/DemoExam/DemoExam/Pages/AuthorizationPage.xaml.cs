﻿using DemoExam.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthorizationPage.xaml
    /// </summary>
    public partial class AuthorizationPage : Page
    {
        public AuthorizationPage()
        {
            App.MainWindowInstance.Title = "Авторизация";
            InitializeComponent();
            AuthBTN.Click += (sender, e) =>
            {
                var user = AuthorizeUser(LoginTB.Text, PasswordTB.Password);

                if (user is null) return;

                switch (user.IdRole)
                {
                    case 1:
                        App.MainWindowInstance.MyFrame.Navigate(new AdministratorPage());
                        break;
                    default:
                        MessageBox.Show("У пользователя не задана роль", "Не задана роль", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                }
            };
        }

        public User AuthorizeUser(string login, string password)
        {
            if(string.IsNullOrEmpty(login.Trim()) || string.IsNullOrEmpty(password.Trim()))
            {
                MessageBox.Show("Поля логина и пароля пустые", "Поля пустые", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }

            var user = App.DataContext.User.FirstOrDefault(u => u.Login.ToLower() == login.Trim().ToLower()
                                                            && u.Password == password.Trim());

            if(user is null)
            {
                MessageBox.Show("Пользователя с таким логином и паролем не существует", "Пользователя не существует", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return user;
        }
    }
}
