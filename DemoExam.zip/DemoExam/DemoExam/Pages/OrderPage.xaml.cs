﻿using DemoExam.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrderPage.xaml
    /// </summary>
    public partial class OrderPage : Page
    {


        public ObservableCollection<Order> Orders
        {
            get { return (ObservableCollection<Order>)GetValue(MyPropertyProperty); }
            set { SetValue(MyPropertyProperty, value); }
        }

        public static readonly DependencyProperty MyPropertyProperty =
            DependencyProperty.Register("MyProperty", typeof(ObservableCollection<Order>), typeof(OrderPage));


        public OrderPage()
        {
            App.MainWindowInstance.Title = "Страницы заказа";
            App.DataContext.Order.Load();
            Orders = App.DataContext.Order.Local;
            InitializeComponent();
            BackToAdminPanelBTN.Click += (sender, e) =>
            {
                App.MainWindowInstance.MyFrame.Navigate(new AdministratorPage());
            };
        }
    }
}
