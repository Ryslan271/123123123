﻿using DemoExam.Model;
using DemoExam.Windows;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam.Pages
{
    public partial class AdministratorPage : Page
    {
        public ObservableCollection<User> Users
        {
            get { return (ObservableCollection<User>)GetValue(UsersProperty); }
            set { SetValue(UsersProperty, value); }
        }

        public static readonly DependencyProperty UsersProperty =
            DependencyProperty.Register("Users", typeof(ObservableCollection<User>), typeof(AdministratorPage));


        public AdministratorPage()
        {
            App.DataContext.User.Load();
            Users = App.DataContext.User.Local;
            InitializeComponent();
            App.MainWindowInstance.Title = "Администратор";
            AddUserBTN.Click += (sender, e) =>
            {
                new AddUserWindow().Show();
            };

            AddShiftBTN.Click += (sender, e) =>
            {
                App.MainWindowInstance.MyFrame.Navigate(new ShiftUsersPage());
            };

            ShowOrdersBTN.Click += (sender, e) =>
            {
                App.MainWindowInstance.MyFrame.Navigate(new OrderPage());
            };
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            App.DataContext.SaveChanges();
        }
    }
}
